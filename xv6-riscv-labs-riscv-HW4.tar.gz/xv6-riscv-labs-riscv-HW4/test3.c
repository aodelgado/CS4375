#include "kernel/types.h"
#include "user/user.h"
#include <stdio.h>
#include <stdlib.h>

int main() {
    const PAGE_SIZE = 4000; //4kB common size for page in 32 bit system.
    const NUM_PAGES = 4;
    char *mem = malloc(PAGE_SIZE * NUM_PAGES); //Get the size of the page size and the number of pages to get appropriate memory needed.
    if (mem == 0) {
        printf("Memory allocation failed\n"); 
        exit(0);
    }
    else{ //For statement will iterate through the memory allocated to various places in the pages.
        for (int i = 0; i < NUM_PAGES; i+=2) { //i+=2 so not all pages are touched, only some
            mem[i * PAGE_SIZE] = 't'; 
        }
    }
    free(mem);
    exit(0);
}
