#include "kernel/types.h"
#include "user/user.h"
#include <stdio.h>
#include <stdlib.h>

int main() {
  
    char *mem = malloc(1000); //Allocate memory using malloc to mem
    if (mem == 0) { //Return error if there are no values in the mem pointer
        printf("Memory allocation failed\n");
        exit(0);
    }

    free(mem); //free allocated memory from mem
    exit(0);
}
