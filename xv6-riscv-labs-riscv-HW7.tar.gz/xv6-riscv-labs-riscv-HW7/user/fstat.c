#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"

int main(int argc, char *argv[]) {
  if (argc != 2) {
    printf("Usage: %s <file or directory>\n", argv[0]);
    exit(0);
  }

  char *path = argv[1];
  struct stat st;

  if (fstat(open(path, 0), &st) < 0) {
    printf("fstat: cannot stat %s\n", path);
    exit(0);
  }
  printf("File: %s\nType: %d\nSize: %d\nInode: %d\nLinks: %d\n",
         path, st.type, st.size, st.ino, st.nlink);

  exit(0);
}


