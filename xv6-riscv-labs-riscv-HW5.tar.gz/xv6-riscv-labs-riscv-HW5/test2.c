#include "kernel/types.h"
#include "user/user.h"
#include <stdio.h>
#include <stdlib.h>

int main() {
    char *mem = malloc(1000);
    if (mem == 0) {
        printf("Memory allocation failed\n");
        exit(0);
    }
    else{ //used to touch different parts of the memory allocated
    mem[5] = 't';
    mem[108] = 't';
    mem[78] = 't';
    }
    free(mem);
    exit(0);
}
